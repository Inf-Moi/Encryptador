
document.getElementById('encryptForm').addEventListener('submit', function(event) {
    event.preventDefault();

    let text = document.getElementById('text').value;
    let key = document.getElementById('key').value;

    let encryptedText = encryptText(text, key);

    document.getElementById('result').textContent = encryptedText;
});

function encryptText(text, key) {
    let result = '';
    for (let i = 0; i < text.length; i++) {
        let charCode = text.charCodeAt(i);
        let keyCode = key.charCodeAt(i % key.length);
        let encryptedCharCode = charCode ^ keyCode;
        result += String.fromCharCode(encryptedCharCode);
    }
    return result;
}
